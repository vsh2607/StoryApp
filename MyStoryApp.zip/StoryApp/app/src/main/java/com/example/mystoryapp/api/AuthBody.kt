package com.example.mystoryapp.api

data class AuthBody(
    val name : String,
    val email : String  ,
    val password : String

)
