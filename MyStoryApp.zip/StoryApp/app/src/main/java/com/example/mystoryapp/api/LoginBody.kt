package com.example.mystoryapp.api

data class LoginBody(
    val email : String,
    val password : String
)