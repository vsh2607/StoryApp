package com.example.mystoryapp.model

data class LoginUserData(
    val token : String,
    val name : String,
    val email : String
)
